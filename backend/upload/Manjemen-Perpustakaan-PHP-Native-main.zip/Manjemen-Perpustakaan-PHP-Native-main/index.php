<?php
// Redirect to a new page
header("Location: ./auth");
exit(); // Ensure that following code is not executed
?>